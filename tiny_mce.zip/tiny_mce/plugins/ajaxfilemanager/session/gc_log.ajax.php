<?php die(); ?>
gc start at 31/Dec/2010 11:59:40
